package proyecto;

public enum EstadoAsignatura {
	SUPERADO, CURSADO, ABANDONADO

}
